package edu.utsa.cs3443.yas418_lab3.model;

import android.content.Context;
import android.content.res.AssetManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Team {
    private ArrayList<Avenger> avengers;

    public Team() {
        avengers = new ArrayList<>();
    }

    public void loadAvengers(Context context) throws IOException {
        AssetManager assetManager = context.getAssets();
        InputStream inputStream = assetManager.open("data.txt");
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String line;
        while((line = reader.readLine()) != null) {
            String[] fields = line.split(",");
            if (fields.length == 8) {
                //Populate arraylist with fields
            }

        }
    }
}
