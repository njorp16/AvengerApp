package edu.utsa.cs3443.yas418_lab3.model;

public abstract class Person {

    private String avengerName;
    private int avengerHeightFeet;
    private int avengerHeightInches;
    private int avengerWeight;

    public Person(String avengerName, int avengerHeightFeet, int avengerHeightInches, int avengerWeight) {
        this.avengerName = avengerName;
        this.avengerHeightFeet = avengerHeightFeet;
        this.avengerHeightInches = avengerHeightInches;
        this.avengerWeight = avengerWeight;
    }

    public String getAvengerName() {
        return avengerName;
    }

    public void setAvengerName(String avengerName) {
        this.avengerName = avengerName;
    }

    public int getAvengerHeightFeet() {
        return avengerHeightFeet;
    }

    public void setAvengerHeightFeet(int avengerHeightFeet) {
        this.avengerHeightFeet = avengerHeightFeet;
    }

    public int getAvengerHeightInches() {
        return avengerHeightInches;
    }

    public void setAvengerHeightInches(int avengerHeightInches) {
        this.avengerHeightInches = avengerHeightInches;
    }

    public int getAvengerWeight() {
        return avengerWeight;
    }

    public void setAvengerWeight(int avengerWeight) {
        this.avengerWeight = avengerWeight;
    }

    public String toString() {
        return "Name: "+ avengerName + ", Height: " + avengerHeightFeet + "'" + avengerHeightInches + "\"" + "Weight: " + avengerWeight + "lbs";
    }



}
