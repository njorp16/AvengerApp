package edu.utsa.cs3443.yas418_lab3.model;

public class Avenger extends Person {
    private String avengerAlias;
    private String avengerLocation;
    private Boolean hasPowers;

    public Avenger (String avengerName, int avengerHeightFeet, int avengerHeightInches, int avengerWeight, String avengerAlias, String avengerLocation, boolean hasPowers) {
        super(avengerName, avengerHeightFeet, avengerHeightInches, avengerWeight);
        this.avengerAlias = avengerAlias;
        this.avengerLocation = avengerLocation;
        this.hasPowers = hasPowers;
    }

    public String getAvengerAlias() {
        return avengerAlias;
    }

    public void setAvengerAlias (String avengerAlias) {
        this.avengerAlias = avengerAlias;
    }

    public String getAvengerLocation() {
        return avengerLocation;
    }

    public void setAvengerLocation(String avengerLocation) {
        this.avengerLocation = avengerLocation;
    }

    public Boolean getHasPowers() {
        return hasPowers;
    }

    public void setHasPowers(boolean hasPowers) {
        this.hasPowers = hasPowers;
    }

    public String toString() {
        String powers = hasPowers ? "Yes" : "No";
        return super.toString() + ", Alias: " + avengerAlias + ", Location: " + avengerLocation + ", Powers?: " + hasPowers;
    }
}

